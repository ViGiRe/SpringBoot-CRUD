package com.app.main.serviceimpl;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.app.main.repository.HomeRepository;
import com.app.main.model.Student;
import com.app.main.serviceInt.Iservice;

@Service
public class HomeService implements Iservice{
	@Autowired
	HomeRepository repo;
	
	public String savedata(Student s) {
		
		repo.save(s);
		
		return "successfully saved in db";
	}

	@Override
	public Student getalldata(int id) {
		
		//Student s=repo.findById(id).get();
		Student s=repo.getById(id);
		return s;
	}

	@Override
	public String update(Student s) {
		repo.save(s);
		return "Data updated";
	}

	@Override
	public String deletedata(int id) {
		repo.deleteById(id);
		return "Data Deleted Successfully";
	}

	@Override
	public Iterable<Student> getdata(){
	//	Iterable<Student> slist=repo.findAll();
		Iterable<Student> slist=repo.getallStudents();
		return slist;
	}

	@Override
	public void updateName(String name, int id) {
		
		repo.updateStudentById(id, name);
	}

	

	
	


}

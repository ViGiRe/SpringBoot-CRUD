package com.app.main.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.main.model.Student;

@Repository
public interface HomeRepository extends JpaRepository<Student, Integer>{
	//custom Query
	@Query("from Student")
	public List<Student> getallStudents();
	
	@Query("from Student s where s.id=:id1")
	public Student getById(@Param("id1") int id);
	
	@Modifying
	@Query("update Student s set s.name = :name where s.id = :id1")
	public void updateStudentById(@Param("id1") int id,@Param("name") String name);

}

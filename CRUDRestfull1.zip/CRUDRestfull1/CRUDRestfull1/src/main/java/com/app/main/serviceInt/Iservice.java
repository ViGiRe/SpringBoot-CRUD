package com.app.main.serviceInt;

import com.app.main.model.Student;

public interface Iservice {

	String savedata(Student s);

	Student getalldata(int id);

	String update(Student s);

	String deletedata(int id);

	Iterable<Student> getdata();

	void updateName(String name, int id);


}

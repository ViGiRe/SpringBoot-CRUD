package com.app.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.main.model.Student;
import com.app.main.serviceInt.Iservice;

@RestController
@CrossOrigin("*")
public class MyController {
	@Autowired
	 Iservice ser;
	
	@PostMapping("/insertData")
	public String insertdata(@RequestBody Student s) {
		
		System.out.println(s.getAddr());
		
		String msg=ser.savedata(s);
		return msg;
		
	}
	
	@GetMapping("/getdata/{id}")
	public Student getalldata(@PathVariable("id") int id) {
	
		return ser.getalldata(id);
		
	}
	
	@PutMapping("/updateData/{id}")
	public String updatedata(@RequestBody Student s) {
		String msg=ser.update(s);
		return msg;
		
	}
	
	@DeleteMapping("/deleteData/{id}")
	public String deletedata(@PathVariable("id") int id) {
		
		String msg=ser.deletedata(id);
		
		return msg;
		
	}
	@GetMapping("/getAlldata")
	public Iterable<Student> getstudata() {
		
		Iterable<Student> slist=ser.getdata();
		
		return slist;
		
	}
	
	@PutMapping("/updatename/{id}")
	public void updateStudent(@RequestBody Student s,@PathVariable("id") int id) {
		
	 ser.updateName(s.getName(),id);
		
	}
}
